/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.taller_corte2.modell;

import com.mycompany.taller_corte2.modell.campo_entrenamiento;
import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author JERLEY
 */
public class medicos extends campo_entrenamiento {
    
    Random randt=new Random();
    
    
    private String fecha_atencion;
    private String hora_atencion;
    static ArrayList<medicos> arramed=new ArrayList<>();
    
    public medicos(){
        super();
    }

    public medicos(String fecha_atencion, String hora_atencion) {
        this.fecha_atencion = fecha_atencion;
        this.hora_atencion = hora_atencion;
    }

    public medicos(String fecha_atencion, String hora_atencion, long id, String nombre, String apellido, int edad) {
        super(id, nombre, apellido, edad);
        this.fecha_atencion = fecha_atencion;
        this.hora_atencion = hora_atencion;
    }
    public int size(){
        return arramed.size();
    }
    
    public medicos obtener(int posicion){
        return arramed.get(posicion);
    }
    
    public boolean isempesp() {
        return arramed.isEmpty();
    }

    public void llenaarray (String fecha_atencion, String hora_atencion, long id, String nombre, String apellido, int edad) {
        medicos med=new medicos( fecha_atencion,  hora_atencion,  id,  nombre,  apellido,  edad);
        arramed.add(med);
    }
    
    public boolean repetid(long id){
        
        medicos med=new medicos();
        
        for(int i=0;i<med.size();i++){
            
            if(med.obtener(i).getId()==id){
                return false;
            }
        }
        return true;
    }
    

    
    
    @Override
    public void concentracion() {
        int nrandt=randt.nextInt(1,2);
        switch(nrandt){
            case 1:
                System.out.println("El medico está distraido y no ha trabajado optimamente");
                ;break;
            case 2:
                System.out.println("El medico esta plenamente concentrado");
                ;break;
        
        }
        
    }

    @Override
    public void viajar() {
        int random=randt.nextInt(1, 5);
        switch(random){
            case 1:
                System.out.println("El medico viajo a China");
                ;break;
            case 2:
                System.out.println("El medico viajo a Colombia");
                ;break;
            case 3:
                System.out.println("El medico se quedo en casa");
               ;break;
            case 4:
                System.out.println("El medico viajo a Australia");
              ;break;
            case 5:
                System.out.println("El medico viajo a Perú");
                ;break;
                   
        }
        
    }


    public String getFecha_atencion() {
        return fecha_atencion;
    }

    public void setFecha_atencion(String fecha_atencion) {
        this.fecha_atencion = fecha_atencion;
    }

    public String getHora_atencion() {
        return hora_atencion;
    }

    public void setHora_atencion(String hora_atencion) {
        this.hora_atencion = hora_atencion;
    }

    @Override
    public String toString() {
        return  super.toString()+"\n"+"medicos[* " + ", fecha_atencion=" + this.getFecha_atencion() + ", hora_atencion=" + this.getFecha_atencion() + ']';
    }

    
    
}
