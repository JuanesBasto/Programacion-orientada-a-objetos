/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.taller_corte2.modell;

import com.mycompany.taller_corte2.modell.campo_entrenamiento;

/**
 *
 * @author JERLEY
 */
public abstract class jefe_masajista extends campo_entrenamiento {
    private long id_jefemasajista=0;
    private String nombre_jefemasajista="nohay";
    private String apellido_jefemasajista="nohay";
    private int edad_jefemasajista=0;
    private String observaciones="nohay";
    
    public jefe_masajista(){
        super();
    }

    public jefe_masajista(long id_jefemasajista, String nombre_jefemasajista, String apellido_jefemasajista, int edad_jefemasajista, String observaciones) {
        this.id_jefemasajista = id_jefemasajista;
        this.nombre_jefemasajista = nombre_jefemasajista;
        this.apellido_jefemasajista = apellido_jefemasajista;
        this.edad_jefemasajista = edad_jefemasajista;
        this.observaciones = observaciones;
    }

    public jefe_masajista(long id_jefemasajista, String nombre_jefemasajista, String apellido_jefemasajista, int edad_jefemasajista, String observaciones, long id, String nombre, String apellido, int edad) {
        super(id, nombre, apellido, edad);
        this.id_jefemasajista = id_jefemasajista;
        this.nombre_jefemasajista = nombre_jefemasajista;
        this.apellido_jefemasajista = apellido_jefemasajista;
        this.edad_jefemasajista = edad_jefemasajista;
        this.observaciones = observaciones;
    }

    public long getId_jefemasajista() {
        return id_jefemasajista;
    }

    public void setId_jefemasajista(long id_jefemasajista) {
        this.id_jefemasajista = id_jefemasajista;
    }

    public String getNombre_jefemasajista() {
        return nombre_jefemasajista;
    }

    public void setNombre_jefemasajista(String nombre_jefemasajista) {
        this.nombre_jefemasajista = nombre_jefemasajista;
    }

    public String getApellido_jefemasajista() {
        return apellido_jefemasajista;
    }

    public void setApellido_jefemasajista(String apellido_jefemasajista) {
        this.apellido_jefemasajista = apellido_jefemasajista;
    }

    public int getEdad_jefemasajista() {
        return edad_jefemasajista;
    }

    public void setEdad_jefemasajista(int edad_jefemasajista) {
        this.edad_jefemasajista = edad_jefemasajista;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }
    
    @Override
    public abstract void concentracion();
    @Override
    public abstract void viajar();

    @Override
    public String toString() {
        return super.toString()+"\n"+"jefe_masajista(\n"+ "------Datos del jefe de los masajistas------------\n" + "* id_jefemasajista=" + this.getId_jefemasajista() + ", nombre_jefemasajista=" + this.getNombre_jefemasajista() + ", apellido_jefemasajista=" + this.getApellido_jefemasajista() + ", edad_jefemasajista=" + this.getEdad_jefemasajista() + ", observaciones=" + this.getObservaciones() + '.';
    }
    
    
    
}
