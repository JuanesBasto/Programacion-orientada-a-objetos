/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.taller_corte2.modell;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author JERLEY
 */
public class esposa extends futbolista {

    Random randt = new Random();

    private long id_esposa = 0;
    private String nombre_esposa = "nohay";
    private String apellido_esposa = "nohay";
    private int edad_esposa = 0;
    static ArrayList<esposa> arraesposa = new ArrayList<>();

    public esposa() {
        super();
    }

    public esposa(long id_esposa, String nombre_esposa, String apellido_esposa, int edad_esposa, long id_futbolista, String nombre_futbolista, String apellido_futbolista, int edad_futbolista, int numero_camiseta, String puesto_encampo) {
        super(id_futbolista, nombre_futbolista, apellido_futbolista, edad_futbolista, numero_camiseta, puesto_encampo);
        this.id_esposa = id_esposa;
        this.nombre_esposa = nombre_esposa;
        this.apellido_esposa = apellido_esposa;
        this.edad_esposa = edad_esposa;

    }

    public esposa(long id_esposa, String nombre_esposa, String apellido_esposa, int edad_esposa, long id_futbolista, String nombre_futbolista, String apellido_futbolista, int edad_futbolista, int numero_camiseta, String puesto_encampo, long id, String nombre, String apellido, int edad) {
        super(id_futbolista, nombre_futbolista, apellido_futbolista, edad_futbolista, numero_camiseta, puesto_encampo, id, nombre, apellido, edad);
        this.id_esposa = id_esposa;
        this.nombre_esposa = nombre_esposa;
        this.apellido_esposa = apellido_esposa;
        this.edad_esposa = edad_esposa;

    }

    @Override
    public void viajar() {
        int random = randt.nextInt(1, 5);
        switch (random) {
            case 1:
                System.out.println("la mujer del futbolista viajo a Estambul, ");
                ;
                break;
            case 2:
                System.out.println("La esposa viajo con el futbolista, ");
                ;
                break;
            case 3:
                System.out.println("La mujer del futbolista se quedo en casa, ");
                ;
                break;
            case 4:
                System.out.println("La mujer del futbolista viajo a México, ");
                ;
                break;
            case 5:
                System.out.println("La mujer del futbolista viajo a USA, ");
                ;
                break;

        }

    }

    @Override
    public void concentracion() {

        int nrandt = randt.nextInt(1, 3);
        switch (nrandt) {
            case 1:
                System.out.println("La esposa esta ayudando a concentrarse al jugardor");
                ;
                break;
            case 2:
                System.out.println("La esposa esta distrayendo al jugador");
                ;
                break;
            case 3:
                System.out.println("La esposa esta causandole problemas al futbolista");
                ;
                break;
        }

    }
    public boolean repetidesposa(long id){
        
        esposa esp=new esposa();
        
        for(int i=0;i<esp.size();i++){
            
            if(esp.obtener(i).getId_esposa()==id){
                return false;
            }
        }
        return true;
    }

    public esposa obtener(int posicion){
        return arraesposa.get(posicion);
    }
    
    public boolean isempesp() {
        return arraesposa.isEmpty();
    }
    
    public int size(){
        return arraesposa.size();
    }

    public void llenaarray(long id_esposa, String nombre_esposa, String apellido_esposa, int edad_esposa, long id_futbolista, String nombre_futbolista, String apellido_futbolista, int edad_futbolista, int numero_camiseta, String puesto_encampo) {
    esposa esp = new esposa(id_esposa, nombre_esposa, apellido_esposa, edad_esposa, id_futbolista, nombre_futbolista, apellido_futbolista, edad_futbolista, numero_camiseta, puesto_encampo, id_futbolista, nombre_futbolista, apellido_futbolista, edad_futbolista);
    arraesposa.add(esp);
}

    public ArrayList<esposa> getesposa() {
       
        return arraesposa;
        
    }

    public long getId_esposa() {
        return id_esposa;
    }

    public void setId_esposa(long id_esposa) {
        this.id_esposa = id_esposa;
    }

    public String getNombre_esposa() {
        return nombre_esposa;
    }

    public void setNombre_esposa(String nombre_esposa) {
        this.nombre_esposa = nombre_esposa;
    }

    public String getApellido_esposa() {
        return apellido_esposa;
    }

    public void setApellido_esposa(String apellido_esposa) {
        this.apellido_esposa = apellido_esposa;
    }

    public int getEdad_esposa() {
        return edad_esposa;
    }

    public void setEdad_esposa(int edad_esposa) {
        this.edad_esposa = edad_esposa;
    }

    @Override
    public String toString() {
        return super.toString() + "\n" + "(* ID de la esposa del jugador=" + this.getId_esposa() + " Nombre de la esposa del jugador=" + this.getNombre_esposa() + " Apellido de la esposa del jugador=" + this.getApellido_esposa() + " Edad de la esposa del jugador=" + this.getEdad_esposa() + ']';
    }

}
