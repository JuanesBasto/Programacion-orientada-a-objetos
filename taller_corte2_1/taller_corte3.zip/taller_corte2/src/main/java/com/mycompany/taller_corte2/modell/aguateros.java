/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.taller_corte2.modell;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author JERLEY
 */
public class aguateros extends campo_entrenamiento {

    Random randt = new Random();

    private int numero_chaleco;
    static ArrayList<aguateros> arraguatero=new ArrayList<>();
     
    public aguateros() {
        super();
    }

    public aguateros(int numero_chaleco) {
        this.numero_chaleco = numero_chaleco;
    }

    public aguateros(int numero_chaleco, long id, String nombre, String apellido, int edad) {
        super(id, nombre, apellido, edad);
        this.numero_chaleco = numero_chaleco;
    }

    public int getNumero_chaleco() {
        return numero_chaleco;
    }

    public void setNumero_chaleco(int numero_chaleco) {
        this.numero_chaleco = numero_chaleco;
    }

    @Override
    public void concentracion() {
        int nrandt = randt.nextInt(1, 2);
        switch (nrandt) {
            case 1:
                System.out.println("El aguatero está distraido y no ha mojado a varios jugadores");
                ;
                break;
            case 2:
                System.out.println("El aguatero esta plenamente concentrado");
                ;
                break;
        }
    }
    public int size(){
        return arraguatero.size();
    }
    
    public aguateros obtener(int posicion){
        return arraguatero.get(posicion);
    }

    public boolean isempesp() {
        return arraguatero.isEmpty();
    }
    
    public boolean repetidoid(long id){
        
        aguateros agu=new aguateros();
        
        for(int i=0;i<agu.size();i++){
            
            if(agu.obtener(i).getId()==id){
                return false;
            }
        }
        return true;
    }
    
    public boolean repetidochaleco(int chaleco){
        
        aguateros agu=new aguateros();
        
        for(int i=0;i<agu.size();i++){
            
            if(agu.obtener(i).getNumero_chaleco()==chaleco){
                return false;
            }
        }
        return true;
    }
    

    public void llenaarray(int numero_chaleco, long id, String nombre, String apellido, int edad) {
        aguateros aguat=new aguateros( numero_chaleco,  id,  nombre,  apellido,  edad);
        arraguatero.add(aguat);
    }

    
    @Override
    public void viajar() {
        int random = randt.nextInt(1, 5);
        switch (random) {
            case 1:
                System.out.println("El medico viajo a China y se comio un perro");
                ;
                break;
            case 2:
                System.out.println("El aguatero viajo a Paris");
                ;
                break;
            case 3:
                System.out.println("El aguatero se quedo en casa");
                ;
                break;
            case 4:
                System.out.println("El aguatero viajo al mundial");
                ;
                break;
            case 5:
                System.out.println("El aguatero viajo a Venezuela y paso hambre");
                ;
                break;
        }
    }

    public void servir_agua() {

        int random = randt.nextInt(1, 3);
        switch (random) {
            case 1:
                System.out.println("El aguatero ha abastecido a los jugadores con agua");
                ;
                break;
            case 2:
                System.out.println("El aguatero derramó toda el agua");
                ;
                break;
            case 3:
                System.out.println("El aguatero se tomó toda el agua para el partido");
                ;
                break;

        }

    }

    @Override
    public String toString() {
        return super.toString() + "[* " + ", numero de chaleco= " + this.getNumero_chaleco() + ']';
    }

}
