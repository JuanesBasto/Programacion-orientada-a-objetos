/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.taller_corte2.modell;

import com.mycompany.taller_corte2.modell.jefe_masajista;
import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author JERLEY
 */
public class masajista extends jefe_masajista {
    
    Random randt=new Random();
    
    private long id_masajista;
    private String nombre_masajista;
    private String apellido_masajista;
    private int edad_masajista;
    private String titulo_universitario;
    private int año_de_experiencia;
    static ArrayList<masajista> arramasaje=new ArrayList<>();
    
    public masajista(){
        super();
    }

    public masajista(long id_masajista, String nombre_masajista, String apellido_masajista, int edad_masajista, String titulo_universitario, int año_de_experiencia) {
        this.id_masajista = id_masajista;
        this.nombre_masajista = nombre_masajista;
        this.apellido_masajista = apellido_masajista;
        this.edad_masajista = edad_masajista;
        this.titulo_universitario = titulo_universitario;
        this.año_de_experiencia = año_de_experiencia;
    }

    public masajista(long id_masajista, String nombre_masajista, String apellido_masajista, int edad_masajista, String titulo_universitario, int año_de_experiencia, long id_jefemasajista, String nombre_jefemasajista, String apellido_jefemasajista, int edad_jefemasajista, String observaciones) {
        super(id_jefemasajista, nombre_jefemasajista, apellido_jefemasajista, edad_jefemasajista, observaciones);
        this.id_masajista = id_masajista;
        this.nombre_masajista = nombre_masajista;
        this.apellido_masajista = apellido_masajista;
        this.edad_masajista = edad_masajista;
        this.titulo_universitario = titulo_universitario;
        this.año_de_experiencia = año_de_experiencia;
    }

    public masajista(long id_masajista, String nombre_masajista, String apellido_masajista, int edad_masajista, String titulo_universitario, int año_de_experiencia, long id_jefemasajista, String nombre_jefemasajista, String apellido_jefemasajista, int edad_jefemasajista, String observaciones, long id, String nombre, String apellido, int edad) {
        super(id_jefemasajista, nombre_jefemasajista, apellido_jefemasajista, edad_jefemasajista, observaciones, id, nombre, apellido, edad);
        this.id_masajista = id_masajista;
        this.nombre_masajista = nombre_masajista;
        this.apellido_masajista = apellido_masajista;
        this.edad_masajista = edad_masajista;
        this.titulo_universitario = titulo_universitario;
        this.año_de_experiencia = año_de_experiencia;
    }
    
    public boolean isempty() {
        return arramasaje.isEmpty();
    }
    public void llenaarray (long id_masajista, String nombre_masajista, String apellido_masajista, int edad_masajista, String titulo_universitario, int año_de_experiencia, long id_jefemasajista, String nombre_jefemasajista, String apellido_jefemasajista, int edad_jefemasajista, String observaciones) {
        masajista masj=new masajista( id_masajista,  nombre_masajista,  apellido_masajista,  edad_masajista,  titulo_universitario,  año_de_experiencia,  id_jefemasajista,  nombre_jefemasajista,  apellido_jefemasajista,  edad_jefemasajista,  observaciones);
        arramasaje.add(masj);
    }

    public int arraysize() {
        return arramasaje.size();
    }

    public masajista obtener(int posicion){
        return arramasaje.get(posicion);
                
        
    }
    public boolean repetid(long id){
        
       masajista masj=new masajista();
        
        for(int i=0;i<masj.arraysize();i++){
            
            if(masj.obtener(i).getId_masajista()==id){
                return false;
            }
        }
        return true;
    }
    
    public long getId_masajista() {
        return id_masajista;
    }

    public void setId_masajista(long id_masajista) {
        this.id_masajista = id_masajista;
    }

    public String getNombre_masajista() {
        return nombre_masajista;
    }

    public void setNombre_masajista(String nombre_masajista) {
        this.nombre_masajista = nombre_masajista;
    }

    public String getApellido_masajista() {
        return apellido_masajista;
    }

    public void setApellido_masajista(String apellido_masajista) {
        this.apellido_masajista = apellido_masajista;
    }

    public int getEdad_masajista() {
        return edad_masajista;
    }

    public void setEdad_masajista(int edad_masajista) {
        this.edad_masajista = edad_masajista;
    }

    public String getTitulo_universitario() {
        return titulo_universitario;
    }

    public void setTitulo_universitario(String titulo_universitario) {
        this.titulo_universitario = titulo_universitario;
    }

    public int getAño_de_experiencia() {
        return año_de_experiencia;
    }

    public void setAño_de_experiencia(int año_de_experiencia) {
        this.año_de_experiencia = año_de_experiencia;
    }

    @Override
    public void concentracion() {
        int nrandt=randt.nextInt(1,2);
        switch(nrandt){
            case 1:
                System.out.println("El masajista esta desconcentrado y empeora la condicion de los jugadores");
                ;break;
            case 2:
                System.out.println("El masajista esta concentrado y los jugadores se sienten mejor");
                ;break;
            
        }
        
    }

    @Override
    public void viajar() {
        int random=randt.nextInt(1, 5);
        switch(random){
            case 1:
                System.out.println("El masajista viajo a corea y se volvio un dictador ");
                ;break;
            case 2:
                System.out.println("El masajista viajo con su familia de vacaciones");
                ;break;
            case 3:
                System.out.println("El masajista se quedo en casa");
               ;break;
            case 4:
                System.out.println("El masajista viajo a México y lo robaron");
              ;break;
            case 5:
                System.out.println("El masajista viajo a inglaterra y se robo un monumento maya");
                ;break;
                   
        }
    }
    
    public void ejercicios_masaje(){
        int nrandt=randt.nextInt(1,2);
        switch(nrandt){
            case 1:
                System.out.println("El masajista esta haciando masajes intensivos");
                ;break;
            case 2:
                System.out.println("El masajista esta haciendo una sesion de masajes por día");
                ;break;
            
        }
    }

    @Override
    public String toString() {
        return super.toString()+"\n"+"masajista[* " + "id_masajista=" + this.getId_masajista() + ", nombre_masajista=" + this.getNombre_masajista() + ", apellido_masajista=" + this.getApellido_masajista() + ", edad_masajista=" + this.getEdad_masajista() + ", titulo_universitario=" + this.getTitulo_universitario() + ", año_de_experiencia=" + this.getAño_de_experiencia() + ']';
    }
    
    
    
}
