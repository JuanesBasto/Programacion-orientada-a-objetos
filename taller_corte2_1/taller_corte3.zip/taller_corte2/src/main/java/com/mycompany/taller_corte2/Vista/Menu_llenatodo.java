/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.taller_corte2.Vista;

import com.mycompany.taller_corte2.controller.controlador;
import com.mycompany.taller_corte2.modell.masajista;
import com.mycompany.taller_corte2.modell.validaciones;
import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JTextField;

/**
 *
 * @author JERLEY
 */
public class Menu_llenatodo extends JFrame {

    JPanel jpanel = new JPanel();
    JTextField caja1 = new JTextField();
    JLabel labelnonum = new JLabel();

    public void label() {

        //titulo del uso del jframe
        JLabel jlabel = new JLabel();
        jlabel.setText("Menu de llenado de datos");
        jlabel.setForeground(Color.DARK_GRAY);
        jlabel.setBounds(125, 20, 300, 60);
        jlabel.setFont(new Font("ARIAL", Font.ITALIC, 20));
        jpanel.add(jlabel);

    }

    public Menu_llenatodo() {
        this.setSize(500, 500);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        //this.setUndecorated(true);
        this.setTitle("Menu llenado de todos los empleados");
        this.setResizable(false);

        jpanel.setBackground(Color.yellow);
        jpanel.setLayout(null);
        this.add(jpanel);
        botonewemp();
        label();
        caja1();
        labelop1();
        labelop2();
        labelop3();
        labelop4();
        labelop5();
        labelop6();

    }

    public void caja1() {

        caja1.setBounds(140, 350, 170, 25);
        caja1.setToolTipText("ingrese una opcion");
        caja1.setFont(new Font("ARIAL", Font.HANGING_BASELINE, 18));
        jpanel.add(caja1);

    }

    public void labelop1() {
        JLabel labelop1 = new JLabel();
        labelop1.setBounds(100, 80, 250, 30);
        labelop1.setText("1.Ingrese nuevo futbolista");
        labelop1.setFont(new Font("ARIAL", Font.PLAIN, 20));
        jpanel.add(labelop1);
    }

    public void labelop2() {
        JLabel labelop2 = new JLabel();
        labelop2.setBounds(100, 110, 250, 30);
        labelop2.setText("2.Ingrese nuevo entrenador");
        labelop2.setFont(new Font("ARIAL", Font.PLAIN, 20));
        jpanel.add(labelop2);
    }

    public void labelop3() {
        JLabel labelop3 = new JLabel();
        labelop3.setBounds(100, 140, 250, 30);
        labelop3.setText("3.Ingrese nuevo aguatero");
        labelop3.setFont(new Font("ARIAL", Font.PLAIN, 20));
        jpanel.add(labelop3);
    }

    public void labelop4() {
        JLabel labelop4 = new JLabel();
        labelop4.setBounds(100, 170, 250, 30);
        labelop4.setText("4.Ingrese nuevo médico");
        labelop4.setFont(new Font("ARIAL", Font.PLAIN, 20));
        jpanel.add(labelop4);
    }

    public void labelop5() {
        JLabel labelop5 = new JLabel();
        labelop5.setBounds(100, 200, 250, 30);
        labelop5.setText("5.Ingrese nuevo masajista");
        labelop5.setFont(new Font("ARIAL", Font.PLAIN, 20));
        jpanel.add(labelop5);
    }

    public void labelop6() {
        JLabel labelop6 = new JLabel();
        labelop6.setBounds(100, 230, 250, 30);
        labelop6.setText("6.Ir a menu");
        labelop6.setFont(new Font("ARIAL", Font.PLAIN, 20));
        jpanel.add(labelop6);
    }
    
    public void labelnonum() {
        labelnonum.setText("Error, usted no ingresó un número");
        labelnonum.setForeground(Color.red);
        labelnonum.setBounds(100, 300, 320, 30);
        labelnonum.setFont(new Font("ARIAL", Font.PLAIN, 20));
        jpanel.add(labelnonum);

    }

    public void botonewemp() {
        menu_futbolista fut = new menu_futbolista();
        Menu_entrenador ent = new Menu_entrenador();
        Menu_aguatero agu = new Menu_aguatero();
        Menu_doctor doc = new Menu_doctor();
        Menu_jefeMasaje jef = new Menu_jefeMasaje();
        Menu_masajista masj=new Menu_masajista(0,"nohay","nohay",0,"nohay");
        validaciones vali = new validaciones();
        JButton botonewemp = new JButton();
        botonewemp.setBounds(150, 390, 150, 30);
        botonewemp.setText("Aceptar");
        botonewemp.setFont(new Font("ARIAL", Font.PLAIN, 20));
        jpanel.add(botonewemp);
        ActionListener oyente = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controlador ct=new controlador();
                inicio start=new inicio();
                if (e.getSource() == botonewemp) {

                    String op = caja1.getText();
                    boolean valinum = vali.esnum(op);
                    if (valinum == false) {

                        labelnonum();
                    }
                    int opint = Integer.parseInt(caja1.getText());
                    setVisible(false);

                    if (opint == 1) {
                        System.out.println(ct.arrayempesposa());
                        fut.setVisible(true);
                    } else if (opint == 2) {
                        ent.setVisible(true);

                    } else if (opint == 3) {
                        agu.setVisible(true);
                    } else if (opint == 4) {
                        doc.setVisible(true);
                    } else if (opint == 5) {
                        if(ct.isemptymasj()==true){
                           
                        jef.setVisible(true);
                        }else{
                       
                            jef.setVisible(false);
                             masj.setVisible(true);
                        }
                    } else if (opint == 6){
                       start.setVisible(true);
                    }

                }
            }
        };
        botonewemp.addActionListener(oyente);
    }

}