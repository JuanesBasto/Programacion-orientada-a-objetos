/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.taller_corte2.modell;

import com.mycompany.taller_corte2.modell.campo_entrenamiento;
import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author JERLEY
 */
public class entrenadores extends campo_entrenamiento {
    
        Random randt=new Random();
    
         
        private String cedula_donde_viene;
        private long numero_interno_federacion_futbol;
        static ArrayList<entrenadores> arratrain=new ArrayList<>();
        
        public entrenadores(){
            super();
        }

    public entrenadores(String cedula_donde_viene, long numero_interno_federacion_futbol) {
        this.cedula_donde_viene = cedula_donde_viene;
        this.numero_interno_federacion_futbol = numero_interno_federacion_futbol;
    }

    public entrenadores(String cedula_donde_viene, long numero_interno_federacion_futbol, long id, String nombre, String apellido, int edad) {
        super(id, nombre, apellido, edad);
        this.cedula_donde_viene = cedula_donde_viene;
        this.numero_interno_federacion_futbol = numero_interno_federacion_futbol;
    }

    public boolean repetid(long id){
        
        entrenadores train = new entrenadores();
        
        for(int i=0;i<train.size();i++){
            
            if(train.obtener(i).getId()==id){
                return false;
            }
        }
        return true;
    }
    public boolean repetinumf(long numf){
        
        entrenadores train = new entrenadores();        
        for(int i=0;i<train.size();i++){
            
            if(train.obtener(i).getNumero_interno_federacion_futbol()==numf){
                return false;
            }
        }
        return true;
    }
    
    public boolean isempesp() {
        return arratrain.isEmpty();
    }

    public int size(){
        return arratrain.size();
    }
    
    public entrenadores obtener(int posicion){
        return arratrain.get(posicion);
    }
    
    public void llenaarray (String cedulaviene, long numFede, long id, String nombre,String apellido,int edad) {
        entrenadores train=new entrenadores(cedulaviene, numFede, id, nombre, apellido, edad);
        arratrain.add(train);
    }

    public void mostrararray() {
        for (int i = 0; i < arratrain.size(); i++) {
             
        }
    }
        
        
    @Override
    public void concentracion() {
    int nrandt=randt.nextInt(1,2);
        switch(nrandt){
            case 1:
                System.out.println("El entrenador esta desconcentrado y hace que los jugadores se desordenen, ");
                ;break;
            case 2:
                System.out.println("El entrenador esta concentrado y el equipo juega mejor que boca jr, ");
                ;break;
            
        }
    }

    @Override
    public void viajar() {
         int random=randt.nextInt(1, 5);
        switch(random){
            case 1:
                System.out.println("El entrenador viajo a japon y se volvió otaku, ");
                ;break;
            case 2:
                System.out.println("El entrenador viajo a alemania y se volvio nazi, ");
                ;break;
            case 3:
                System.out.println("El entrenador viajo a arabia saudi y compró un avion de oro, ");
               ;break;
            case 4:
                System.out.println("El entrenador viajo a españa y se volvió un tío, ");
              ;break;
            case 5:
                System.out.println("El entrenador viajo a Amsterdam y se echó una traba criminal, ");
                ;break;
      
    }
    }
        
        public void segir_partido(){
            int nrandt=randt.nextInt(1,3);
        switch(nrandt){
            case 1:
                System.out.println("El entrenador esta metido en el partido, ");
                ;break;
            case 2:
                System.out.println("El entrenador está siguiendo a messi en instagram, ");
                ;break;
            case 3: 
                System.out.println("El entrenador esta siguiendo al aguatero por agua, ");
            
        }
            
        }
        
        public void seguir_entrenamiento(){
            int nrandt=randt.nextInt(1,3);
        switch(nrandt){
            case 1:
                System.out.println("El entrenador esta analizando a todos los jugadores");
                ;break;
            case 2:
                System.out.println("El entrenador está siguiendo a AMLO en twitter");
                ;break;
            case 3: 
                System.out.println("El entrenador está analizando mejores alineaciones y estrategias");
            
        }
        }

    

    public String getCedula_donde_viene() {
        return cedula_donde_viene;
    }

    public void setCedula_donde_viene(String cedula_donde_viene) {
        this.cedula_donde_viene = cedula_donde_viene;
    }

    public long getNumero_interno_federacion_futbol() {
        return numero_interno_federacion_futbol;
    }

    public void setNumero_interno_federacion_futbol(long numero_interno_federacion_futbol) {
        this.numero_interno_federacion_futbol = numero_interno_federacion_futbol;
    }

    @Override
    public String toString() {
        return super.toString()+"\n"+"entrenadores[* " +", cedula_donde_viene=" + this.getCedula_donde_viene() + ", numero_interno_federacion_futbol=" + this.getNumero_interno_federacion_futbol() + ']';
    }
        
        
        
}
