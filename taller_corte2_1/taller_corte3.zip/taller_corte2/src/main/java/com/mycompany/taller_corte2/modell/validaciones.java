/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.taller_corte2.modell;

/**
 *
 * @author JERLEY
 */
public class validaciones {
    
    
    
    
    
    public boolean esnum(String posinum){
        
        posinum=posinum.trim();
       try{
            Integer.parseInt(posinum);
            return true;
        }catch(NumberFormatException e){
            return false;
        }
    }
    public boolean esid(String posinum){
        posinum=posinum.trim();
       try{
            Long.valueOf(posinum);
            return true;
        }catch(NumberFormatException e){
            return false;
        }
    }
    
    public boolean rango(String num){
        
        int num1=Integer.valueOf(num);
        if(num1>0 && num1<=3){
            return true;
        }else{
            return false;
        }
        
    }
    
    
    
}
