/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.taller_corte2.Vista;

import com.mycompany.taller_corte2.controller.controlador;
import com.mycompany.taller_corte2.modell.masajista;
import com.mycompany.taller_corte2.modell.validaciones;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author JERLEY
 */
public class inicio extends JFrame {

    public JPanel panel1 = new JPanel();
    public JTextField caja = new JTextField();
    public JLabel error = new JLabel();
    public JLabel error1 = new JLabel();
    public JButton boton = new JButton();

    public inicio() {
        this.setSize(500, 500);
        this.setResizable(false);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        panel1.setBackground(Color.getHSBColor(171, 68, 60));
        panel1.setLayout(null);
        this.add(panel1);

        autores();
        titulo();
        texto1();
        texto2();
        texto3();
        caja1();

        boton();

    }

    public void autores(){
        JLabel nom1 = new JLabel();
        nom1.setBounds(0,0,500,20);
        nom1.setText("Hecho por: Jerley Saieth Hernandez Calvo & Juan Esteban Basto Dávila");
        panel1.add(nom1);
    }
    public void titulo() {
        JLabel titulo = new JLabel();
        titulo.setBounds(150, 100, 200, 20);
        titulo.setText("Menu");
        titulo.setFont(new Font("ARIAL", Font.PLAIN, 18));
        panel1.add(titulo);
    }

    public void texto1() {
        JLabel texto1 = new JLabel();
        texto1.setBounds(50, 180, 200, 20);
        texto1.setText("1.Ingrese nuevo campo");
        texto1.setFont(new Font("ARIAL", Font.PLAIN, 18));
        panel1.add(texto1);
    }

    public void texto2() {
        JLabel texto2 = new JLabel();
        texto2.setBounds(50, 210, 200, 20);
        texto2.setText("2.Mostrar datos");
        texto2.setFont(new Font("ARIAL", Font.PLAIN, 18));
        panel1.add(texto2);
    }

    public void texto3() {
        JLabel texto3 = new JLabel();
        texto3.setBounds(50, 240, 200, 20);
        texto3.setText("3.salir");
        texto3.setFont(new Font("ARIAL", Font.PLAIN, 18));
        panel1.add(texto3);
    }

    public void texto4() {
        JLabel texto4 = new JLabel();
        texto4.setBounds(15, 270, 200, 20);
        texto4.setText("ingrese una opcion");
        texto4.setFont(new Font("ARIAL", Font.PLAIN, 18));
        panel1.add(texto4);
    }

    public void caja1() {
        caja.setBounds(150, 300, 200, 20);
        caja.setFont(new Font("ARIAL", Font.PLAIN, 18));
        panel1.add(caja);
    }

    public void error() {

        error.setBounds(100, 400, 350, 20);
        error.setText("Usted no ha ingresado un numero");
        error.setFont(new Font("ARIAL", Font.PLAIN, 18));
        error.setForeground(Color.red);

        panel1.add(error);
    }

    public void error1() {

        error1.setBounds(100, 400, 350, 20);
        error1.setText("Opcion invalida");
        error1.setFont(new Font("ARIAL", Font.PLAIN, 18));
        error1.setForeground(Color.red);

        panel1.add(error1);
    }

    public void boton() {
        Menu_llenatodo meth2 = new Menu_llenatodo();
        menu_mostradodatos meth3=new menu_mostradodatos();
        masajista masj=new masajista();
        boton.setBounds(150, 350, 200, 20);
        boton.setText("aceptar");
        boton.setFont(new Font("ARIAL", Font.PLAIN, 18));
        panel1.add(boton);
        ActionListener oyente = new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                controlador ct = new controlador();
                if (e.getSource() == boton) {
                    String num = caja.getText();
                    boolean exepnum = ct.valid(num, 1);
                    if (exepnum == false) {
                        error();
                    }
                    boolean rangnum = ct.valid(num, 2);
                    if (rangnum == false) {
                        error1();
                    }
                    int numop = Integer.parseInt(num);
                    switch (numop) {
                        case 1:
                            
                                setVisible(false);
                                meth2.setVisible(true);
                            

                            break;
                        case 2:
                            
                            setVisible(false);
                           meth3.setVisible(true);  
                            ;
                            break;
                        case 3:
                          
                            System.exit(0);
                            break;

                    }

                }

            }

        };
        boton.addActionListener(oyente);
    }

}
