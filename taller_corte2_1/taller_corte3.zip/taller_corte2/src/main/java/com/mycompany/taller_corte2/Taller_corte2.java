/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.taller_corte2;


import com.mycompany.taller_corte2.Vista.inicio;
import java.util.Scanner;

/**
 *
 * @author JERLEY
 */
public class Taller_corte2 {

    Scanner tec = new Scanner(System.in);
/*
    public void menu(ArrayList arraesposa, ArrayList arraguatero, ArrayList arraentrenador, ArrayList arramedico, ArrayList arramasajista) {
        Taller_corte2 taller = new Taller_corte2();
        validaciones vali = new validaciones();

        // Espacio para las variables que utiliza el menú
        int r=0;
        int op;
        int opcampo = 0;
        int jefm = 1;
        long idcampo=0;
        
        String nombrecampo="null";
        String apellidocampo="null";
        int edadcampo=0;
        long id_futbolistaM = 0;
        String nombre_futbolistaM = " ";
        String apellido_futbolistaM = " ";
        int edad_futbolistaM = 0;
        int numero_camisetaM = 0;
        String puesto_encampoM = " ";
        long id_esposaM = 02;
        String nombre_esposaM = "0";
        String apellido_esposaM = "0";
        int edad_esposaM = 0;
        int opesposa;
        long id_entrenadorM;
        String nombre_entrenadorM;
        String apellido_entrenadorM;
        int edad_entrenadorM;
        String cedula_donde_vieneM;
        long numero_interno_federacion_futbolM;
        long id_aguaterosM;
        String nombre_aguaterosM;
        String apellido_aguaterosM;
        int edad_aguaterosM;
        int num_chaleco;
        long id_medicoM;
        String nombre_medicoM;
        String apellido_medicoM;
        int edad_medicoM;
        String fecha_atencionM;
        String hora_atencionM;
        long id_jefemasajistaM = 0;
        String nombre_jefemasajistaM = "no hay";
        String apellido_jefemasajistaM = "no hay";
        int edad_jefemasajistaM = 0;
        String observacionesM = "no hay";
        long id_masajistaM;
        String nombre_masajistaM;
        String apellido_masajistaM;
        int edad_masajistaM;
        String titulo_universitarioM;
        int año_de_experienciaM;
        /*
        
        
        
        Codigo fuente del menú
        
        
        
        
        System.out.println("---------------Menu---------------");
        System.out.println("1. ingresar los datos del campo de entrenamiento");
        //añadir opcion de buscar dato
        System.out.println("2. mostrar datos");
        System.out.println("3.salir");
        System.out.println("------------------------------------------");
        System.out.println("Ingrese una opcion");
        op = tec.nextInt();
        switch (op) {
            case 1:

                boolean valcamp=arraesposa.isEmpty();
                if(valcamp==true){
                tec.nextLine();
                System.out.println("----------Digite los datos del campo de entrenamiento-------");
                System.out.println("*****************************************************************");
                System.out.print("Digite el id del campo de entrenamiento: ");
                idcampo = tec.nextLong();
                tec.nextLine();
                System.out.print("Digite el nombre del campo de entrenamiento: ");
                nombrecampo = tec.nextLine();
                System.out.print("Digite el apellido del campo de entrenamiento: ");
                apellidocampo = tec.nextLine();
                System.out.print("Digite  la edad del campo de entrenamiento: ");
                edadcampo = tec.nextInt();
                /*
                Aqui se colocan los datos del campo de entrenamiento
                y se colocan en la primera posicion del array de esposa
                por lo tanto la primera posicion del array de la esposa
                sol tendrá los datos del campo
                las demas oasiciones solo tendran las posiciones de los jugadores
                y sus respectivas esposas en tal caso
                 
                esposa mujerfut = new esposa(id_esposaM, nombre_esposaM, apellido_esposaM, edad_esposaM, id_futbolistaM, nombre_futbolistaM, apellido_futbolistaM, edad_futbolistaM, numero_camisetaM, puesto_encampoM, idcampo, nombrecampo, apellidocampo, edadcampo);
                arraesposa.add(mujerfut);
                }

                externo:
                while (opcampo != -1) {
                    nombre_esposaM = "0";
                    nombre_jefemasajistaM = "no hay";
                    System.out.println("-------Menu de llenado de datos-----");
                    System.out.println("1.añadir nuevo futbolista");
                    System.out.println("2.añadir nuevo entrenador");
                    System.out.println("3.añadir nuevo aguatero");
                    System.out.println("4.añadir nuevo medico");
                    System.out.println("5.añadir nuevo masajista" + "\n" + "(*la primeravez que vallas a añadir un masajista, ingresas los datos del jefe de masajistas*)");
                    System.out.println("6.terminar registro de datos");
                    System.out.println("-------------------------------------------------");
                    opcampo = tec.nextInt();
                    switch (opcampo) {
                        case 1:
                            tec.nextLine();
                            System.out.print("Digite el id del futbolista: ");
                            id_futbolistaM = tec.nextLong();
                             for (int i = 0; i < arraesposa.size(); i++) {
                                esposa t4 = (esposa) arraesposa.get(i);
                                long valiidfutbolista=t4.getId_futbolista();
                                while (id_futbolistaM == valiidfutbolista ) {
                                    
                                    System.out.println("Este id de persona ya está registradp");
                                    System.out.println("por favor digite otro id");
                                    id_futbolistaM = tec.nextLong();
                                    for (int j = 0; j < arraesposa.size(); j++) {
                                        esposa t5 = (esposa) arraesposa.get(j);
                                        valiidfutbolista=t5.getNumero_camiseta();
                                        while(id_futbolistaM==valiidfutbolista){
                                            System.out.println("Este id de persona ya está registradp");
                                            System.out.println("por favor digite otro id");
                                            id_futbolistaM = tec.nextLong();
                                        }
                                    }

                                
                                }
                            }
                            System.out.print("Digite el nombre del futbolista: ");
                            nombre_futbolistaM = tec.next();
                            tec.nextLine();
                            System.out.print("Digite el apellido del futbolista: ");
                            apellido_futbolistaM = tec.nextLine();
                            System.out.print("Digite la edad del futbolista: ");
                            while(r==0){
                            try{
                            edad_futbolistaM = tec.nextInt();
                            r=1;
                            }catch(java.util.InputMismatchException ex){
                                System.out.println("error, solo puede digitar numeros");
                                r=0;
                                tec.nextLine();
                            }
                            }
                            System.out.print("Digite el dorsal que usa el jugardor: ");
                            numero_camisetaM = tec.nextInt();
                            for (int k = 0; k < arraesposa.size(); k++) {
                                esposa t4 = (esposa) arraesposa.get(k);
                                int validorsal=t4.getNumero_camiseta();
                                while (numero_camisetaM == validorsal ) {
                                    
                                    System.out.println("Dorsal en uso");
                                    System.out.println("por favor digite otro dorsal");
                                    numero_camisetaM = tec.nextInt();
                                    for (int L = 0; L < arraesposa.size(); L++) {
                                        esposa t5 = (esposa) arraesposa.get(L);
                                        validorsal=t5.getNumero_camiseta();
                                        while(numero_camisetaM==validorsal){
                                            System.out.println("orsal en uso");
                                            System.out.println("por favor digite otro dorsal");
                                            numero_camisetaM = tec.nextInt();
                                        }
                                    }

                                
                                }
                            }
                            
                            tec.nextLine();
                            System.out.print("Digite la posicion en la que juega el jugador: " + "\n");
                            puesto_encampoM = tec.nextLine();
                            System.out.println("-------------------------------------------------");
                            System.out.println("¿El jugador tiene esposa?");
                            System.out.println("1. si");
                            System.out.println("2. no");
                            opesposa = tec.nextInt();
                            boolean valiopesposa = vali.valiopesposa(opesposa);
                            while (valiopesposa != true) {
                                System.out.println("Usted ha digitado una opcion incorrecta, por favor ingrese una opcion valida");
                                opesposa = tec.nextInt();
                                valiopesposa = vali.valiopesposa(opesposa);
                            }
                            switch (opesposa) {
                                case 1:

                                    tec.nextLine();
                                    System.out.println("----------------Datos de la esposa---------------");
                                    System.out.print("Digite el id de la esposa del jugador: ");
                                    id_esposaM = tec.nextLong();
                                    for (int m = 0; m < arraesposa.size(); m++) {
                                        esposa t6 = (esposa) arraesposa.get(m);
                                        long validesposa = t6.getId_esposa();
                                        while (id_esposaM == validesposa) {

                                            System.out.println("Esta mujer ya es esposa de un jugador... ¿chapulin?");
                                            System.out.println("por favor digite el id de una mujer que no sea esposa de uno de los jugadpres ya registrados");
                                            id_esposaM = tec.nextLong();
                                            for (int n = 0; n < arraesposa.size(); n++) {
                                                esposa t7 = (esposa) arraesposa.get(n);
                                                validesposa = t7.getId_esposa();

                                                while (id_esposaM == validesposa) {
                                                    System.out.println("Esta mujer ya es esposa de un jugador... ¿chapulin?");
                                                    System.out.println("por favor digite el id de una mujer que no sea esposa de uno de los jugadpres ya registrados");
                                                    id_esposaM = tec.nextLong();
                                                }
                                            }

                                        }
                                    }
                                    System.out.print("Digite el nombre de la esposa del jugador: ");
                                    nombre_esposaM = tec.next();
                                    tec.nextLine();
                                    System.out.print("Digite el apellido de la esposa del jugador: ");
                                    apellido_esposaM = tec.nextLine();
                                    System.out.print("Digite la edad de la esposa del jugador: ");
                                    edad_esposaM = tec.nextInt();
                                    System.out.println("--------------------");
                                    System.out.println("Registro realizado con exito");
                                    ;
                                    break;
                                case 2:

                                    System.out.println("Registro realizado con exito");

                                    ;
                                    break;
                            }
                            esposa mujerfut=new esposa(id_esposaM, nombre_esposaM, apellido_esposaM, edad_esposaM, id_futbolistaM, nombre_futbolistaM, apellido_futbolistaM, edad_futbolistaM, numero_camisetaM, puesto_encampoM, idcampo, nombrecampo, apellidocampo, edadcampo);
                            arraesposa.add(mujerfut);
                            ;
                            break;
                        case 2:
                            tec.nextLine();
                            System.out.println("----------Datos del entrenador-------");
                            System.out.print("Digite el id del entrenador: ");
                            id_entrenadorM = tec.nextLong();
                            for (int p = 0; p < arraentrenador.size(); p++) {
                                        entrenadores t8 = (entrenadores) arraentrenador.get(p);
                                        long valientrenador = t8.getId_entrenador();
                                        while (id_entrenadorM == valientrenador) {

                                            System.out.println("Esta persona ya está registrada como entrenador");
                                            System.out.println("por favor digite otra persona");
                                            id_entrenadorM = tec.nextLong();
                                            for (int q = 0; q < arraentrenador.size(); q++) {
                                                entrenadores t9 = (entrenadores) arraentrenador.get(q);
                                                valientrenador = t9.getId_entrenador();

                                                while (id_entrenadorM == valientrenador) {
                                                    System.out.println("Esta persona ya está registrada como entrenador");
                                                    System.out.println("por favor digite otra persona");
                                                    id_entrenadorM = tec.nextLong();
                                                }
                                            }

                                        }
                                    }
                            tec.nextLine();
                            System.out.print("Digite el nombre del entrenador: ");
                            nombre_entrenadorM = tec.nextLine();
                            System.out.print("Digite el apellido del entrenador: ");
                            apellido_entrenadorM = tec.nextLine();
                            System.out.print("Digite la edad del entrenador: ");
                            edad_entrenadorM = tec.nextInt();
                            tec.nextLine();
                            System.out.print("Digite el lugar de expedicion de la cedula del entrenador: ");
                            cedula_donde_vieneM = tec.nextLine();
                            System.out.println("Digute el numero interno de la federacion del entrenador");
                            numero_interno_federacion_futbolM = tec.nextLong();

                            for (int i = 0; i < arraentrenador.size(); i++) {
                                entrenadores t1 = (entrenadores) arraentrenador.get(i);
                                long valinufed=t1.getNumero_interno_federacion_futbol();
                                while (numero_interno_federacion_futbolM == valinufed) {
                                    
                                    System.out.println("numero de federacion no valido");
                                    System.out.println(" por favor digite otro numero de federacion");
                                    numero_interno_federacion_futbolM = tec.nextLong();
                                    for (int j = 0; j < arraentrenador.size(); j++) {
                                        entrenadores t5 = (entrenadores) arraentrenador.get(j);
                                        valinufed=t5.getNumero_interno_federacion_futbol();
                                        while(numero_interno_federacion_futbolM==valinufed){
                                            System.out.println("orsal en uso");
                                            System.out.println("por favor digite otro dorsal");
                                            numero_interno_federacion_futbolM = tec.nextLong();
                                        }
                                    }
                                }
                            }

                            entrenadores train = new entrenadores(id_entrenadorM, nombre_entrenadorM, apellido_entrenadorM, edad_entrenadorM, cedula_donde_vieneM, numero_interno_federacion_futbolM);

                            arraentrenador.add(train);

                            ;
                            break;
                        case 3:
                            tec.nextLine();
                            System.out.println("----------Datos del aguatero-------");
                            System.out.print("Digite el id del aguatero: ");
                            id_aguaterosM = tec.nextLong();
                            for (int u = 0; u < arraguatero.size(); u++) {
                                aguateros t10 = (aguateros) arraguatero.get(u);
                                long valiidagua=t10.getId_aguateros();
                                while (id_aguaterosM == valiidagua ) {
                                    
                                    System.out.println("persona ya registrada como aguatero");
                                    System.out.println("por favor digite otro numero de id");
                                    id_aguaterosM = tec.nextLong();
                                    for (int s = 0; s < arraguatero.size(); s++) {
                                        aguateros t5 = (aguateros) arraguatero.get(s);
                                        valiidagua=t5.getNumero_chaleco();
                                        while(id_aguaterosM==valiidagua){
                                            System.out.println("persona ya registrada como aguatero");
                                            System.out.println("por favor digite otro numero de id");
                                            id_aguaterosM = tec.nextLong();
                                        }
                                    }

                                
                                }
                            }
                            System.out.print("Digite el nombre del aguatero: ");
                            tec.nextLine();
                            nombre_aguaterosM = tec.nextLine();
                            System.out.print("Digite el apellido del aguatero: ");
                            apellido_aguaterosM = tec.nextLine();
                            System.out.print("Digite la edad del aguatero: ");
                            edad_aguaterosM = tec.nextInt();
                            System.out.println("Digite el numer de chaleco del aguatero");
                            num_chaleco=tec.nextInt();
                            //verifica que el num de chaleco no este repetido
                            for (int a = 0; a < arraguatero.size(); a++) {
                                aguateros t4 = (aguateros) arraguatero.get(a);
                                int valichal=t4.getNumero_chaleco();
                                while (num_chaleco == valichal ) {
                                    
                                    System.out.println("numero de chaleco no valido");
                                    System.out.println("por favor digite otro numero de chaleco");
                                    num_chaleco = tec.nextInt();
                                    for (int b = 0; b < arraguatero.size(); b++) {
                                        aguateros t5 = (aguateros) arraguatero.get(b);
                                        valichal=t5.getNumero_chaleco();
                                        while(num_chaleco==valichal){
                                            System.out.println("numero de chaleco no valido");
                                            System.out.println("por favor digite otro numero de chaleco");
                                            num_chaleco = tec.nextInt();
                                        }
                                    }

                                
                                }
                            }
                            
                            

                            aguateros aguat = new aguateros(id_aguaterosM, nombre_aguaterosM, apellido_aguaterosM, edad_aguaterosM, num_chaleco);
                            arraguatero.add(aguat);
                            ;
                            break;
                        case 4:

                            tec.nextLine();
                            System.out.println("----------Datos del medico-------");
                            System.out.print("Digite el id del medico: ");
                            id_medicoM = tec.nextInt();
                            for (int i = 0; i < arramedico.size(); i++) {
                                medicos t11 = (medicos) arraguatero.get(i);
                                long validmed=t11.getId_medico();
                                while (id_medicoM == validmed ) {
                                    
                                    System.out.println("persona ya registrada como medico");
                                    System.out.println("por favor digite otro numero de id");
                                    id_medicoM = tec.nextLong();
                                    for (int j = 0; j < arramedico.size(); j++) {
                                        medicos t12 = (medicos) arramedico.get(j);
                                        validmed=t12.getId_medico();
                                        while(id_medicoM==validmed){
                                            System.out.println("persona ya registrada como medico");
                                            System.out.println("por favor digite otro numero de id");
                                            id_medicoM = tec.nextLong();
                                        }
                                    }

                                
                                }
                            }
                            System.out.print("Digite el nombre del medico: ");
                            nombre_medicoM = tec.nextLine();
                            tec.nextLine();
                            System.out.print("Digite el apellido del medico: ");
                            apellido_medicoM = tec.nextLine();
                            System.out.print("Digite le edad del medico: ");
                            edad_medicoM = tec.nextInt();
                            tec.nextLine();
                            System.out.print("Digite la fecha en la que atiende el medico: ");
                            fecha_atencionM = tec.nextLine();

                            System.out.print("Digite la hora en la que atiende el medico: ");
                            hora_atencionM = tec.nextLine();

                            medicos med = new medicos(id_medicoM, nombre_medicoM, apellido_medicoM, edad_medicoM, fecha_atencionM, hora_atencionM);
                            arramedico.add(med);
                            ;
                            break;
                        case 5:
                            if (jefm == 1) {
                                tec.nextLine();
                                System.out.println("-------Datos jefemasajista-------");
                                System.out.print("Digite el id del jefe masajista: ");
                                id_jefemasajistaM = tec.nextLong();
                                System.out.print("Digite el nombre del jefe masajista: ");
                                nombre_jefemasajistaM = tec.next();
                                System.out.print("Digite el apellido del jefe masajista: ");
                                apellido_jefemasajistaM = tec.next();
                                System.out.print("Digite la edad del jefe masajista: ");
                                edad_jefemasajistaM = tec.nextInt();
                                tec.nextLine();
                                System.out.print("Digite las observaciondes del jefe masajista: " + "\n");
                                observacionesM = tec.nextLine();
                                System.out.println("--------------------------------------------------------");

                                jefm = jefm + 1;

                            }

                            System.out.println("---------Datos masajista---------");
                            System.out.print("Digite el id del masajista: ");
                            id_masajistaM = tec.nextLong();
                            for (int t = 0; t < arramasajista.size(); t++) {
                                masajista t13 = (masajista) arramasajista.get(t);
                                long validmasaje=t13.getId_masajista();
                                while (id_masajistaM == validmasaje ) {
                                    
                                    System.out.println("persona ya registrada como masajista");
                                    System.out.println("por favor digite otro numero de id");
                                    id_masajistaM = tec.nextLong();
                                    for (int u = 0; u < arramasajista.size(); u++) {
                                        masajista t14 = (masajista) arramasajista.get(u);
                                        validmasaje=t14.getId_masajista();
                                        while(id_masajistaM==validmasaje){
                                            System.out.println("persona ya registrada como masajista");
                                            System.out.println("por favor digite otro numero de id");
                                            id_masajistaM = tec.nextLong();
                                        }
                                    }

                                
                                }
                            }
                            System.out.print("Digite el nombre del masajista: ");
                            nombre_masajistaM = tec.next();
                            System.out.print("Digite el apellido del masajista: ");
                            apellido_masajistaM = tec.next();
                            System.out.print("Digite la edad del masajista: ");
                            edad_masajistaM = tec.nextInt();
                            tec.nextLine();
                            System.out.print("Digite el tutilo universitario del masajista: ");
                            titulo_universitarioM = tec.nextLine();
                            System.out.print("Digute los años de experiencia del masajista: ");
                            año_de_experienciaM = tec.nextInt();
                            masajista masaje = new masajista(id_masajistaM, nombre_masajistaM, apellido_masajistaM, edad_masajistaM, titulo_universitarioM, año_de_experienciaM, id_jefemasajistaM, nombre_jefemasajistaM, apellido_jefemasajistaM, edad_jefemasajistaM, observacionesM);

                            arramasajista.add(masaje);

                            ;
                            break;
                        case 6:

                            break externo;

                        default:
                            System.out.println("Usted ha digitado una opcion incorrecta");

                    }

                }

                taller.menu(arraesposa, arraguatero, arraentrenador, arramedico, arramasajista);
                ;
                break;

            case 2:
                //espacio para instanciar los objetos de todas las clases hijas
  
                esposa mujer = new esposa();
                medicos med = new medicos();
                aguateros agua = new aguateros();
                entrenadores train = new entrenadores();
                masajista masj = new masajista();
                /*
                este if valida si hay mas posiciones en el array de esposa
                ademas de la posicion 0 que es la que contiene los datos del campo
                en cuyo caso solo exista la posicion 0, imprime que no hay datos de jugadores
                si hay mas posiciones imprime los datos que hay dentro de ellas
                 
                if (arraesposa.size() > 0) {
                    for (int i = 0; i < 1; i++) {
                        esposa t2 = (esposa) arraesposa.get(i);

                        if (!"null".equals(t2.getNombre())) {
                            int campoindice = arraesposa.get(i).toString().indexOf("{") + "{".length();
                            int hastacampo = arraesposa.get(i).toString().indexOf("}", campoindice);
                            String datoscampo = arraesposa.get(i).toString().substring(campoindice, hastacampo);
                            System.out.println(datoscampo);
                        }

                    }
                } else {
                    System.out.println("Usted no ha ingresado ningun campo de entrenamiento");
                    taller.menu(arraesposa, arraguatero, arraentrenador, arramedico, arramasajista);
                }
                if (arraesposa.size() <= 1) {
                    System.out.println("usted no ha digitado datos de jugadores");
                } else {
                    System.out.println("--------Datos de los futbolistas-------------");
                    for (int i = 1; i < arraesposa.size(); i++) {
                        esposa t2 = (esposa) arraesposa.get(i);
                        if ("0".equals(t2.getNombre_esposa())) {
                            int indicefut = arraesposa.get(i).toString().indexOf("[") + "[".length();
                            int hastafut = arraesposa.get(i).toString().indexOf(".", indicefut);
                            String datosfutbolista = arraesposa.get(i).toString().substring(indicefut, hastafut);
                            System.out.println(datosfutbolista);
                            System.out.println("-------------------------resultado de los metodos abstractos");
                            mujer.jugarpartidos();
                            mujer.entrenar();
                            System.out.println("-----------------------------------------");
                        } else {
                            int indicefutcones = arraesposa.get(i).toString().indexOf("[") + "[".length();
                            int hastafutcones = arraesposa.get(i).toString().indexOf(".", indicefutcones);
                            String datosfutbolcones = arraesposa.get(i).toString().substring(indicefutcones, hastafutcones);
                            System.out.println(datosfutbolcones);
                            System.out.println("-------------------------resultado de los metodos abstractos");
                            mujer.jugarpartidos();
                            mujer.entrenar();
                            System.out.println("-----------------------------------------");
                            int indiceesposa = arraesposa.get(i).toString().indexOf("(") + "(".length();
                            int hastaesposa = arraesposa.get(i).toString().indexOf("]", indiceesposa);
                            String datosfutbolista = arraesposa.get(i).toString().substring(indiceesposa, hastaesposa);
                            System.out.println(datosfutbolista);
                            System.out.println("-------------------------resultado de los metodos abstractos");
                            mujer.viajar();
                            mujer.concentracion();
                            System.out.println("--------------------------------------");
                        }

                    }
                }
                /*
                aqui se crea la variable valtarin que mira si el array de entrenador esta vacio
                si esta vacio imprime "usted no ha digitado datos de entrenadores"
                en cuyo caso no este vacio el array imprime todos los datos que contiene
                 
                boolean valtrain = arraentrenador.isEmpty();
                if (valtrain == true) {
                    System.out.println("usted no ha digitado datos de entrenadores");

                } else {
                    System.out.println("--------------------Datos de los entrenadores--------------");
                    for (int i = 0; i < arraentrenador.size(); i++) {

                        

                        int indicetrain = arraentrenador.get(i).toString().indexOf("[") + "[".length();
                        int hastatrain = arraentrenador.get(i).toString().indexOf("}", indicetrain);
                        String datostrain = arraentrenador.get(i).toString().substring(indicetrain, hastatrain);
                        System.out.println(datostrain);
                        System.out.println("-------------------------resultado de los metodos abstractos");
                        train.concentracion();
                        train.segir_partido();
                        train.viajar();
                        train.seguir_entrenamiento();
                        System.out.println("--------------------");

                    }
                }
                /*
                aqui se crea la variable boolean que mira si el array de entrenador esta vacio
                si esta vacio imprime "usted no ha digitado datos de entrenadores"
                en cuyo caso no este vacio el array imprime todos los datos que contiene
                 
                boolean valagua = arraguatero.isEmpty();
                if (valagua == true) {
                    System.out.println("usted no ha digitado datos de aguateros");

                } else {
                    System.out.println("------------------Datos de los aguateros--------------------");
                    for (int i = 0; i < arraguatero.size(); i++) {
                        

                        int indice = arraguatero.get(i).toString().indexOf("[") + "[".length();
                        int hasta = arraguatero.get(i).toString().indexOf("]", indice);
                        String datos = arraguatero.get(i).toString().substring(indice, hasta);
                        System.out.println(datos);
                        System.out.println("-------------------------resultado de los metodos abstractos");

                        agua.concentracion();
                        agua.servir_agua();
                        agua.viajar();
                        System.out.println("-----------------------------------------");

                    }
                }
                /*
                aqui se crea la variable valtarin que mira si el array de entrenador esta vacio
                si esta vacio imprime "usted no ha digitado datos de entrenadores"
                en cuyo caso no este vacio el array imprime todos los datos que contiene
                 
                boolean valmed = arramedico.isEmpty();
                if (valmed == true) {
                    System.out.println("usted no ha digitado datos de medicos");

                } else {
                    System.out.println("-----------------Datos de los medicos-------------------------");

                    for (int i = 0; i < arramedico.size(); i++) {
                       

                        int indice = arramedico.get(i).toString().indexOf("[") + "[".length();
                        int hasta = arramedico.get(i).toString().indexOf("]", indice);
                        String datos = arramedico.get(i).toString().substring(indice, hasta);
                        System.out.println(datos);

                        System.out.println("-------------------------resultado de los metodos abstractos");

                        med.concentracion();
                        med.viajar();
                        System.out.println("-----------------------------------------");

                    }
                }
                /*
                aqui se crea la variable valtarin que mira si el array de entrenador esta vacio
                si esta vacio imprime "usted no ha digitado datos de entrenadores"
                en cuyo caso no este vacio el array imprime todos los datos que contiene
                 
                boolean valmasj = arramasajista.isEmpty();
                if (valmasj == true) {
                    System.out.println("usted no ha digitado datos de masajistas");

                } else {
                    System.out.println("------------------------Datos de los masajistas---------------------");
                    for (int i = 0; i < arramasajista.size(); i++) {
                        masajista t2 = (masajista) arramasajista.get(i);

                        if ("no hay".equals(t2.getNombre_jefemasajista())) {
                            int indice = arramasajista.get(i).toString().indexOf("[") + "[".length();
                            int hasta = arramasajista.get(i).toString().indexOf("]", indice);
                            String datos = arramasajista.get(i).toString().substring(indice, hasta);
                            System.out.println(datos);
                            System.out.println("-------------------------resultado de los metodos abstractos");
                            masj.ejercicios_masaje();
                            masj.viajar();
                            masj.concentracion();
                            System.out.println("-----------------------------------------");

                        } else {

                            int indicejefem = arramasajista.get(i).toString().indexOf("(") + "(".length();
                            int hastajefem = arramasajista.get(i).toString().indexOf(".", indicejefem);
                            String datosjefem = arramasajista.get(i).toString().substring(indicejefem, hastajefem);
                            System.out.println(datosjefem);

                            int indicemasaje = arraguatero.get(i).toString().indexOf("[") + "[".length();
                            int hastamasaje = arraguatero.get(i).toString().indexOf("]", indicemasaje);
                            String datosmasajista = arraguatero.get(i).toString().substring(indicemasaje, hastamasaje);
                            System.out.println(datosmasajista);
                            System.out.println("-------------------------resultado de los metodos abstractos");
                            masj.ejercicios_masaje();
                            masj.viajar();
                            masj.concentracion();
                            System.out.println("-----------------------------------------");
                        }
                    }
                }

                taller.menu(arraesposa, arraguatero, arraentrenador, arramedico, arramasajista);
                ;
                break;
            case 3:

                System.out.println("**********************************");
                System.out.println("Salida");
                System.exit(0);

                ;
                break;
            default:
                System.out.println("Error, opcion no existe");
                taller.menu(arraesposa, arraguatero, arraentrenador, arramedico, arramasajista);
        }

    }
*/

    public static void main(String[] args) {
        /*
        System.out.println("Bienvenido");

        ArrayList<esposa> arraesposa = new ArrayList<>();
        ArrayList<aguateros> arraguatero = new ArrayList<>();
        ArrayList<entrenadores> arraentrenador = new ArrayList<>();
        ArrayList<medicos> arramedico = new ArrayList<>();
        ArrayList<masajista> arramasajista = new ArrayList<>();

        Taller_corte2 taller = new Taller_corte2();
        taller.menu(arraesposa, arraguatero, arraentrenador, arramedico, arramasajista);
        */
       inicio meth5=new inicio();
       meth5.setVisible(true);
       
     
     
    }
}
