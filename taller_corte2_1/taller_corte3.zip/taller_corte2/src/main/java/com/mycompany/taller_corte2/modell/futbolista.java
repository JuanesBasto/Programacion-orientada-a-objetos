/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.taller_corte2.modell;

import com.mycompany.taller_corte2.modell.campo_entrenamiento;
import java.util.Random;

/**
 *
 * @author JERLEY
 */
public abstract class futbolista extends campo_entrenamiento {
    
    Random aleatorio=new Random();
    
    private long id_futbolista;
    private String nombre_futbolista;
    private String apellido_futbolista;
    private int edad_futbolista;
    private int numero_camiseta=0;
    private String puesto_encampo="no";
    
    public futbolista(){
        super();
    }

    public futbolista(long id_futbolista, String nombre_futbolista, String apellido_futbolista, int edad_futbolista, int numero_camiseta, String puesto_encampo) {
        this.id_futbolista = id_futbolista;
        this.nombre_futbolista = nombre_futbolista;
        this.apellido_futbolista = apellido_futbolista;
        this.edad_futbolista = edad_futbolista;
        this.numero_camiseta = numero_camiseta;
        this.puesto_encampo = puesto_encampo;
    }

    public futbolista(long id_futbolista, String nombre_futbolista, String apellido_futbolista, int edad_futbolista, int numero_camiseta, String puesto_encampo, long id, String nombre, String apellido, int edad) {
        super(id, nombre, apellido, edad);
        this.id_futbolista = id_futbolista;
        this.nombre_futbolista = nombre_futbolista;
        this.apellido_futbolista = apellido_futbolista;
        this.edad_futbolista = edad_futbolista;
        this.numero_camiseta = numero_camiseta;
        this.puesto_encampo = puesto_encampo;
    }

    public boolean repetid(long id){
        
        esposa esp=new esposa();
        
        for(int i=0;i<esp.size();i++){
            
            if(esp.obtener(i).getId_futbolista()==id){
                return false;
            }
        }
        return true;
    }
    public boolean repetidorsal(int dorsal){
        
        esposa esp=new esposa();
        
        for(int i=0;i<esp.size();i++){
            
            if(esp.obtener(i).getNumero_camiseta()==dorsal){
                return false;
            }
        }
        return true;
    }
    
    public long getId_futbolista() {
        return id_futbolista;
    }

    public void setId_futbolista(long id_futbolista) {
        this.id_futbolista = id_futbolista;
    }

    public String getNombre_futbolista() {
        return nombre_futbolista;
    }

    public void setNombre_futbolista(String nombre_futbolista) {
        this.nombre_futbolista = nombre_futbolista;
    }

    public String getApellido_futbolista() {
        return apellido_futbolista;
    }

    public void setApellido_futbolista(String apellido_futbolista) {
        this.apellido_futbolista = apellido_futbolista;
    }

    public int getEdad_futbolista() {
        return edad_futbolista;
    }

    public void setEdad_futbolista(int edad_futbolista) {
        this.edad_futbolista = edad_futbolista;
    }

    public int getNumero_camiseta() {
        return numero_camiseta;
    }

    public void setNumero_camiseta(int numero_camiseta) {
        this.numero_camiseta = numero_camiseta;
    }

    public String getPuesto_encampo() {
        return puesto_encampo;
    }

    public void setPuesto_encampo(String puesto_encampo) {
        this.puesto_encampo = puesto_encampo;
    }

    @Override
    public abstract void viajar();

    @Override
    public abstract void concentracion();

    public  void jugarpartidos(){
        int npartidos=aleatorio.nextInt(20, 100);
        System.out.println("el jugador ha jugado " + npartidos + " partidos de 100");
        
    }
    
    public  void entrenar(){
        
        int random=aleatorio.nextInt(1, 4);
        switch(random){
            case 1:
                System.out.println("El futbolista no ha asisitido a los entrenaimentos");
                ;break;
            case 2:
                System.out.println("El futbolista ha asistido a la mitad de los entrenamientos");
                ;break;
            case 3:
                System.out.println("El futbolista ha asistido a la mayoria de entrenamientos");
               ;break;
            case 4:
                System.out.println("El futbolista ha asistido a todos los entrenamientos");
              ;break;
            
        }
        
    }
    
    @Override
    public String toString() {
        return super.toString() +"\n"+"futbolista [* " + "ID del futbolista=" + this.getId_futbolista() + " Nombre del futbolista=" + this.getNombre_futbolista() + " Apellido del futbolista=" + this.getApellido_futbolista() + " Edad del futbolista=" + this.getEdad_futbolista() + " Dorsal que usa=" + this.getNumero_camiseta() + " Puesto en campo=" + this.getPuesto_encampo() + '.';
    }
    
    
    
    
}
