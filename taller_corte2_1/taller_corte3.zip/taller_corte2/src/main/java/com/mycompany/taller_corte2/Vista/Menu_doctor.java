/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.taller_corte2.Vista;

import com.mycompany.taller_corte2.controller.controlador;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

/**
 *
 * @author JERLEY
 */
public class Menu_doctor extends JFrame {
    JPanel panel=new JPanel();
    JTextField caja2=new JTextField();
    JTextField caja3=new JTextField();
    JTextField caja4=new JTextField();
    JTextField caja5=new JTextField();
    JTextField caja6=new JTextField();
    JTextField caja7=new JTextField();
    JLabel errorid=new JLabel();
    
    public void titulo(){
        
        JLabel texto1=new JLabel();
        texto1.setBounds(150, 60, 200, 20);
        texto1.setText("Añadir nuevo medico");
        texto1.setFont(new Font("ARIAL",Font.PLAIN,18));
        
        panel.add(texto1);
        
    }
    
    public Menu_doctor(){
        panel.setLayout(null);
        this.setSize(500, 500);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        panel.setBackground(Color.BLUE);
        this.add(panel);
        
        titulo();
        texto2();
        caja2();
        texto3();
        caja3();
        texto4();
        caja4();
        texto5();
        caja5();
        texto6();
        caja6();
        texto7();
        caja7();
        boton();
    }
    
    public void texto2(){
        JLabel texto2=new JLabel();
        texto2.setBounds(50, 120, 200, 20);
        texto2.setText("Id: ");
        texto2.setFont(new Font("ARIAL",Font.PLAIN,18));
        
        panel.add(texto2);
    }
    
    public void caja2(){
        caja2.setBounds(100, 120, 200, 20);
        caja2.setText("Ingrese un número");
        caja2.setFont(new Font("ARIAL", Font.PLAIN,18));
        panel.add(caja2);
    }
    public void texto3(){
        JLabel texto3=new JLabel();
        texto3.setBounds(50, 150, 200, 20);
        texto3.setText("Nombre: ");
        texto3.setFont(new Font("ARIAL",Font.PLAIN,18));
        
        panel.add(texto3);
    }
    public void caja3(){
        caja3.setBounds(120, 150, 200, 20);
        caja3.setText("Ingrese un nombre");
        caja3.setFont(new Font("ARIAL", Font.PLAIN,18));
        panel.add(caja3);
    }
    public void texto4(){
        JLabel texto4=new JLabel();
        texto4.setBounds(50, 180, 200, 20);
        texto4.setText("Apelido: ");
        texto4.setFont(new Font("ARIAL",Font.PLAIN,18));
        
        panel.add(texto4);
    }
    public void caja4(){
        caja4.setBounds(120, 180, 200, 20);
        caja4.setText("Ingrese un apellido");
        caja4.setFont(new Font("ARIAL", Font.PLAIN,18));
        panel.add(caja4);
    }
    
    public void texto5(){
        JLabel texto5=new JLabel();
        texto5.setBounds(50, 210, 200, 20);
        texto5.setText("Edad: ");
        texto5.setFont(new Font("ARIAL",Font.PLAIN,18));
        
        panel.add(texto5);
    }
    public void caja5(){
        caja5.setBounds(120, 210, 200, 20);
        caja5.setText("Ingrese la edad");
        caja5.setFont(new Font("ARIAL", Font.PLAIN,18));
        panel.add(caja5);
    }
    public void texto6(){
        JLabel texto6=new JLabel();
        texto6.setBounds(50, 240, 200, 20);
        texto6.setText("Fecha de atencion: ");
        texto6.setFont(new Font("ARIAL",Font.PLAIN,18));
        
        panel.add(texto6);
    }
    
    public void caja6(){
        caja6.setBounds(220, 240, 200, 20);
        caja6.setText("Ingrese la fecha");
        caja6.setFont(new Font("ARIAL", Font.PLAIN,18));
        panel.add(caja6);
    }
    
    public void texto7(){
        JLabel texto7=new JLabel();
        texto7.setBounds(50, 270, 240, 20);
        texto7.setText("Hora de atención: ");
        texto7.setFont(new Font("ARIAL",Font.PLAIN,18));
        
        panel.add(texto7);
    }
    public void caja7(){
        
        caja7.setBounds(270, 270, 150, 20);
        caja7.setText("Ingrese la hora");
        caja7.setFont(new Font("ARIAL", Font.PLAIN,18));
        panel.add(caja7);
    }
    
    public void idrepetido(){
       errorid.setBounds(150, 400, 220, 20);
       errorid.setText("el id esta repetido");
       errorid.setFont(new Font("ARIAL",Font.PLAIN,18));
       errorid.setForeground(Color.red);
       errorid.setVisible(false);
       panel.add(errorid);
       
    }

    
    public void boton(){
        JButton boton1=new JButton();
        boton1.setBounds(150, 330, 180, 20);
        boton1.setText("Ingresar los datos");
        boton1.setFont(new Font("ARIAL", Font.PLAIN,18));
        panel.add(boton1);
        ActionListener oyente=new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controlador ct=new controlador();
                Menu_llenatodo meth1=new Menu_llenatodo();
                if(e.getSource()==boton1){
                
                    idrepetido();
                
                    long id=Long.parseLong(caja2.getText());
                    String nombre=caja3.getText();
                    String apellido=caja4.getText();
                    int edad=Integer.parseInt(caja5.getText());
                    String fecha=caja6.getText();
                    String hora=caja7.getText();
                    boolean valid=ct.idmedrepe(id);
                    if(valid==false){
                        errorid.setVisible(true);
                    }else{
                    ct.llenarmed( fecha, hora,id, nombre, apellido, edad);
                    setVisible(false);
                    meth1.setVisible(true);
                    }
                }
            }

           
        };
        boton1.addActionListener(oyente);
    }
}
