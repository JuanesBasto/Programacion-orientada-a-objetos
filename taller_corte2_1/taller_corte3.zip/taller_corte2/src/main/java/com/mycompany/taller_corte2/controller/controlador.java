/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.taller_corte2.controller;

import com.mycompany.taller_corte2.Vista.Menu_esposa;
import com.mycompany.taller_corte2.modell.aguateros;
import com.mycompany.taller_corte2.modell.entrenadores;
import com.mycompany.taller_corte2.modell.esposa;
import com.mycompany.taller_corte2.modell.masajista;
import com.mycompany.taller_corte2.modell.medicos;
import com.mycompany.taller_corte2.modell.validaciones;
import java.util.ArrayList;

/**
 *
 * @author JERLEY
 */
public class controlador {

    public controlador() {

        super();

    }

    public boolean valid(String posinum, int op) {
        validaciones vali = new validaciones();
        switch (op) {
            case 1:
                return vali.esnum(posinum);
            case 2:
                return vali.rango(posinum);
            case 3:
                return vali.esid(posinum);
        }
        return true;
    }

    
    public void llenaraguatero(int numero_chaleco, long id, String nombre, String apellido, int edad) {

        aguateros meth = new aguateros();
        meth.llenaarray(numero_chaleco, id, nombre, apellido, edad);
        
    }

    public void llenartrain(String cedula_donde_viene, long numero_interno_federacion_futbol, long id, String nombre, String apellido, int edad) {
        entrenadores trainers = new entrenadores();
        trainers.llenaarray(cedula_donde_viene, numero_interno_federacion_futbol, id, nombre, apellido, edad);
       
    }

    public void llenarmed(String fecha_atencion, String hora_atencion, long id, String nombre, String apellido, int edad) {

        medicos med = new medicos();
        med.llenaarray(fecha_atencion, hora_atencion, id, nombre, apellido, edad);
        

    }
    
      

    public void llenar_esposa(long id_esposa, String nombre_esposa, String apellido_esposa, int edad_esposa, long id_futbolista, String nombre_futbolista, String apellido_futbolista, int edad_futbolista, int numero_camiseta, String puesto_encampo, boolean bandera) {

        esposa Esposa = new esposa();

        if (bandera == true) {
            Esposa.llenaarray(id_esposa, nombre_esposa, apellido_esposa, edad_esposa, id_futbolista, nombre_futbolista, apellido_futbolista, edad_futbolista, numero_camiseta, puesto_encampo);
        } else {
            id_esposa = 0;
            nombre_esposa = "nohay";
            apellido_esposa = "nohay";
            edad_esposa = 0;

            Esposa.llenaarray(id_esposa, nombre_esposa, apellido_esposa, edad_esposa, id_futbolista, nombre_futbolista, apellido_futbolista, edad_futbolista, numero_camiseta, puesto_encampo);
         
        }

       
    }

    

   

    public void llenar_masaje(long id_masajista, String nombre_masajista, String apellido_masajista, int edad_masajista, String titulo_universitario, int año_de_experiencia, long id_jefemasajista, String nombre_jefemasajista, String apellido_jefemasajista, int edad_jefemasajista, String observaciones) {
        masajista masaje = new masajista();
        boolean bandera = masaje.isempty();

        if (bandera == true) {
            masaje.llenaarray(id_masajista, nombre_masajista, apellido_masajista, edad_masajista, titulo_universitario, año_de_experiencia, id_jefemasajista, nombre_jefemasajista, apellido_jefemasajista, edad_jefemasajista, observaciones);
            
        } else {
            id_jefemasajista = 0;
            nombre_jefemasajista = "nohay";
            apellido_jefemasajista = "nohay";
            edad_jefemasajista = 0;
            observaciones = "nohay";
            masaje.llenaarray(id_masajista, nombre_masajista, apellido_masajista, edad_masajista, titulo_universitario, año_de_experiencia, id_jefemasajista, nombre_jefemasajista, apellido_jefemasajista, edad_jefemasajista, observaciones);
            
        }

    }

    
  
    public int arraesposasize(){
        esposa esp=new esposa();
        return esp.size();
    }
    public int arramasjsize(){
        masajista masj= new masajista();
        return masj.arraysize();
    }

    
    public int arratrainsize(){
        entrenadores train=new entrenadores();
        return train.size();
    }
    
    public int arramedsize(){
        medicos med=new medicos();
        return med.size();
    }
    
    public int arraguasize(){
        aguateros ag=new aguateros();
        return ag.size();
    }
    
    
    public entrenadores obtenertrain(int posicion){
        entrenadores train=new entrenadores();
        return train.obtener(posicion);
    }
    
    public masajista obtenermasj(int posicion){
        masajista masj=new masajista();
        return masj.obtener(posicion);
    }
    public esposa obteneresp(int posicion){
        esposa esp=new esposa();
        return esp.obtener(posicion);
    }
    
    public medicos obtenermed(int posicion){
        medicos med=new medicos();
        return med.obtener(posicion);
    }
    
    public aguateros obteneraguateros(int posicion){
        aguateros agu=new aguateros();
        return agu.obtener(posicion);
    }
    public boolean idmedrepe(long id){
        medicos med = new medicos();
        return med.repetid(id);
    }
    public boolean idrepetidoesp(long id){
        esposa esp=new esposa();
        return esp.repetidesposa(id);
    }
    public boolean idrepetidofut(long id){
        esposa esp=new esposa();
        return esp.repetid(id);
    }
    public boolean dorsalrep(int dorsal){
        esposa esp=new esposa();
        return esp.repetidorsal(dorsal);
    }
    
     public boolean idmasjrepe(long id){
        masajista masj=new masajista();
        return masj.repetid(id);
    }
    
    public boolean idagutrep(long id){
        aguateros agu=new aguateros();
        return agu.repetidoid(id);
    }
    public boolean idagutrep(int chal){
        aguateros agu=new aguateros();
        return agu.repetidochaleco(chal);
    }
    public boolean idtrainrep(long id){
        entrenadores train=new entrenadores();
        return train.repetid(id);
    }
    public boolean idatrainrep(long numf){
        entrenadores train=new entrenadores();
        return train.repetinumf(numf);
    }

    public boolean arrayempesposa() {
        esposa Esposa = new esposa();
        return Esposa.isempesp();
    }
    public boolean arratrainempty(){
        entrenadores train=new entrenadores();
        return train.isempesp();
    }
    public boolean isemptymasj() {
        masajista masj = new masajista();
        return masj.isempty();
    }
    public boolean isemptymed(){
        medicos med=new medicos();
        return med.isempesp();
    }
    public boolean isemptyagu(){
        aguateros agu=new aguateros();
        return agu.isempesp();
    }
    
}
