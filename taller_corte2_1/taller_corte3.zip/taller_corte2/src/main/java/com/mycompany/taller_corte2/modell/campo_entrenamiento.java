/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.taller_corte2.modell;

/**
 *
 * @author JERLEY
 */
public abstract class campo_entrenamiento {
    
    private long id=0;
    private String nombre="nohay";
    private String apellido="nohay";
    private int edad=0;
    
    public campo_entrenamiento(){
        super();
    }

    public campo_entrenamiento(long id, String nombre, String apellido, int edad) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }
    
    
    
    public abstract void concentracion();
    
    public abstract void viajar();

    @Override
    public String toString() {
        return "campo_entrenamiento{" + "ID del campo de entrenamiento=" + this.getId() + "\nNombre del campo de entrenamiento=" + this.getNombre() + "\nApellido del campo de entrenamiento=" + this.getApellido() + "\nEdad del campo de entrenamiento=" + this.getEdad() + '}';
    }
    
    
    
}
